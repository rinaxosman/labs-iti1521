Ceci est une solution alternative de la partie 3 (Maps/Dictionnary), qui n utilise pas un Nested class Pair
