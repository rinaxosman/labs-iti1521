public class TestL4 {

   public static void main(String[] args) {
    TestUtils.runClass(TestL4Post.class);
    TestUtils.runClass(TestL4TextPost.class);
    TestUtils.runClass(TestL4PhotoPost.class);
    TestUtils.runClass(TestL4NewsFeed.class);
  }

}
